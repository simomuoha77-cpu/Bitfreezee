// db.js — fixtures + odds are stored in MongoDB Atlas, same as API keys.
//
// WHY THIS MOVED FROM A LOCAL FILE: Render's free tier has an EPHEMERAL
// filesystem — any local file gets wiped every time the service restarts,
// redeploys, or spins down from inactivity (which free services do
// automatically). That was already the cause of API keys "disappearing"
// earlier, and it turned out to affect fixtures/odds too: every deploy was
// silently discarding all completed AI analysis, forcing a full re-analysis
// of a 2000+ match backlog from scratch on every single push. MongoDB is a
// separate, persistent service, so this data now survives restarts.
//
// SCHEMA: one document per match (not one per day-bucket) in the
// "fixtures" collection, keyed by match id + days bucket. This means
// updating one match's odds is a single atomic upsert that only touches
// that match — not a read-modify-write of an entire day's fixture list —
// so odds updates apply immediately and show up on the very next read from
// anywhere (JuanAi's own UI, BetaKE's API calls), with no risk of two
// concurrent writes clobbering each other's unrelated changes.

const { MongoClient } = require('mongodb');
const footballData = require('./footballData');
const realOdds = require('./realOdds');

const MONGO_URI = process.env.MONGO_URI || '';
const DB_NAME = 'juanai';
const FIXTURES_COLLECTION = 'fixtures';
const KEYS_COLLECTION = 'apikeys';
const WALLETS_COLLECTION = 'partnerwallets'; // partner API key -> wallet base URL + HMAC secret, for real-money casino integration (see walletClient.js)

let client = null;
let mongoReady = false;
let mongoConnectAttempted = false;
let fixturesCollection = null;
let apiKeysCollection = null;
let walletsCollection = null;

// In-memory fallback so the server keeps working (within a single running
// instance) if MONGO_URI is missing/unreachable — same safety net pattern
// as the API-key storage already uses. Data won't survive a restart in
// this fallback mode, which is the exact problem we're fixing, so this is
// only a "don't crash" safety net, not a real substitute for Mongo.
let fixturesFallback = {}; // keyed by `${days}` -> { matches: [...], fetchedAt, updatedAt }
let apiKeysFallback = [];
let walletsFallback = []; // { apiKey, baseUrl, secret, updatedAt }
let usingFallback = false;

async function connectMongo() {
  if (mongoConnectAttempted) return;
  mongoConnectAttempted = true;

  if (!MONGO_URI) {
    console.warn('[db] MONGO_URI not set — fixtures/odds AND API keys will use in-memory storage and will NOT survive a restart. Set MONGO_URI on Render to fix this permanently.');
    usingFallback = true;
    return;
  }

  try {
    client = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 8000 });
    await client.connect();
    const db = client.db(DB_NAME);
    fixturesCollection = db.collection(FIXTURES_COLLECTION);
    apiKeysCollection = db.collection(KEYS_COLLECTION);
    walletsCollection = db.collection(WALLETS_COLLECTION);
    await fixturesCollection.createIndex({ matchId: 1, days: 1 }, { unique: true });
    await fixturesCollection.createIndex({ days: 1 }); // for fetching a whole day-bucket efficiently
    await apiKeysCollection.createIndex({ key: 1 }, { unique: true });
    await walletsCollection.createIndex({ apiKey: 1 }, { unique: true });
    mongoReady = true;
    usingFallback = false;
    console.log('[db] Connected to MongoDB Atlas — fixtures/odds AND API keys will persist across restarts.');
  } catch (e) {
    console.error('[db] MongoDB connection FAILED — falling back to in-memory storage (will not survive a restart): ' + e.message);
    usingFallback = true;
  }
}

const initialConnect = connectMongo();
async function ensureMongo() {
  await initialConnect;
}

// ── Fixtures storage ───────────────────────────────────────────────

// Replaces an entire day-bucket's match list — called by the scheduler's
// fixture refresh. Uses bulkWrite upserts keyed by (matchId, days) so
// existing per-match aiOdds data is naturally preserved for any match that
// appears in both the old and new fetch (MongoDB just updates the fields
// we send; if we don't include aiOdds in this call, it stays untouched —
// unlike the old file-based approach, we don't need to manually copy prior
// odds forward, since we're not overwriting the whole bucket anymore).
async function saveFixtures(days, matches, sport) {
  sport = sport || 'football'; // default keeps every existing caller's behavior byte-for-byte identical
  const bucketKey = sport + ':' + String(days); // namespacing by sport means basketball and football never share a days-bucket, even though match IDs already can't collide (oaio_bball_ vs oaio_/plain numeric) — this keeps querying by sport simple rather than relying on ID-prefix sniffing
  await ensureMongo();
  const now = new Date().toISOString();

  if (usingFallback) {
    const existing = fixturesFallback[bucketKey];
    const existingById = {};
    if (existing) existing.matches.forEach(m => { existingById[String(m.id)] = m; });
    const merged = matches.map(m => {
      const prev = existingById[String(m.id)];
      return prev && prev.aiOdds ? Object.assign({}, m, { aiOdds: prev.aiOdds, aiPrediction: prev.aiPrediction, aiConfidence: prev.aiConfidence, aiAnalysis: prev.aiAnalysis, aiXG: prev.aiXG, aiValueBet: prev.aiValueBet, aiAnalyzedAt: prev.aiAnalyzedAt }) : m;
    });
    fixturesFallback[bucketKey] = { matches: merged, fetchedAt: Date.now(), updatedAt: now };
    // Same cross-bucket cleanup in fallback mode — see the real-Mongo path
    // below for why this matters. Scoped to buckets of the SAME sport only
    // (bucketKey prefix match) — a football match id and a basketball
    // match id are namespaced differently anyway, but this keeps the
    // cleanup's intent explicit rather than relying on that as an
    // implementation detail.
    Object.keys(fixturesFallback).forEach(otherBucketKey => {
      if (otherBucketKey === bucketKey) return;
      if (!otherBucketKey.startsWith(sport + ':')) return;
      const bucket = fixturesFallback[otherBucketKey];
      if (!bucket) return;
      const matchIds = new Set(matches.map(m => String(m.id)));
      bucket.matches = bucket.matches.filter(m => !matchIds.has(String(m.id)));
    });
    return;
  }

  try {
    const ops = matches.map(m => ({
      updateOne: {
        filter: { matchId: String(m.id), days: bucketKey },
        // $set updates the match's base fixture data (teams, date, status,
        // score) WITHOUT touching aiOdds/aiPrediction/etc — those fields are
        // only ever written by upsertMatchOdds below, so a fixture refresh
        // can never accidentally wipe out existing analysis.
        update: { $set: { matchId: String(m.id), days: bucketKey, sport: sport, match: m, fetchedAt: Date.now(), updatedAt: now } },
        upsert: true
      }
    }));
    if (ops.length) await fixturesCollection.bulkWrite(ops);

    // CROSS-BUCKET CLEANUP: a match's kickoff timing can cause it to
    // legitimately satisfy TWO different day-buckets' inclusion criteria at
    // once (e.g. a match near a midnight boundary, or odds-api.io's
    // "still-live from previous day" window overlapping two buckets'
    // checks independently) — this was the actual cause of a match showing
    // FINISHED in one bucket and stuck LIVE in another, since each bucket
    // tracked its own independent copy that never reconciled. Deleting the
    // match from every OTHER bucket OF THE SAME SPORT whenever we save it
    // into this one guarantees exactly one authoritative copy exists at any
    // time — the most recently refreshed one. Scoped by sport (regex
    // prefix) so a basketball fixture refresh can never delete a football
    // bucket's data even if match IDs ever happened to coincide.
    const matchIds = matches.map(m => String(m.id));
    if (matchIds.length) {
      await fixturesCollection.deleteMany({
        matchId: { $in: matchIds },
        days: { $ne: bucketKey, $regex: '^' + sport + ':' }
      });
    }
  } catch (e) {
    console.error('[db] saveFixtures failed, falling back to in-memory: ' + e.message);
    fixturesFallback[bucketKey] = { matches, fetchedAt: Date.now(), updatedAt: now };
  }
}

async function getFixtures(days, sport) {
  sport = sport || 'football'; // default keeps every existing caller's behavior byte-for-byte identical
  const bucketKey = sport + ':' + String(days);
  await ensureMongo();
  if (usingFallback) return fixturesFallback[bucketKey] || null;

  try {
    const docs = await fixturesCollection.find({ days: bucketKey }).toArray();
    if (!docs.length) return null;
    const matches = docs.map(d => {
      let m = Object.assign({}, d.match, d.aiOdds ? {
        aiOdds: d.aiOdds,
        aiPrediction: d.aiPrediction,
        aiConfidence: d.aiConfidence,
        aiAnalysis: d.aiAnalysis,
        aiXG: d.aiXG,
        aiValueBet: d.aiValueBet,
        aiAnalyzedAt: d.aiAnalyzedAt
      } : {});
      // Recalculate the estimated live minute at READ time, not just at the
      // last save — this keeps it advancing in near-real-time (checked on
      // every API/UI request) instead of only updating every 2 minutes
      // when the fixture refresh job happens to run. Applies whenever a
      // match is still live (IN_PLAY or PAUSED/half-time) so a match that
      // enters or leaves half-time between reads gets its status corrected
      // here too, not just its minute. Football-data.org's minute is
      // already a real value from the source, left untouched. Sport-gated:
      // basketball matches use basketballData's quarter-based clock
      // estimator instead — calling football's half-based one on a
      // basketball match would silently corrupt its minute/status (wrong
      // break points, wrong regulation-time cap).
      if (m.minuteIsEstimated && (m.status === 'IN_PLAY' || m.status === 'PAUSED') && m.utcDate) {
        if (sport === 'basketball') {
          const basketballData = require('./basketballData');
          const clock = basketballData.estimateBasketballClock(m.utcDate);
          if (clock) {
            m.minute = clock.displayMinute;
            m.isHalftime = clock.isBreak && clock.quarter === 2;
            m.quarter = clock.quarter;
            m.status = clock.isBreak ? 'PAUSED' : 'IN_PLAY';
          }
        } else {
          const est = footballData.estimateMatchMinute(m.utcDate, m.htObservedAt || null);
          if (est) {
            m.minute = est.minute;
            m.isHalftime = est.isHalftime;
            m.status = est.isHalftime ? 'PAUSED' : 'IN_PLAY';
          }
        }
      }
      return m;
    });
    const updatedAt = docs.reduce((latest, d) => d.updatedAt > latest ? d.updatedAt : latest, docs[0].updatedAt);
    const fetchedAt = Math.max(...docs.map(d => d.fetchedAt || 0));
    return { matches, fetchedAt, updatedAt };
  } catch (e) {
    console.error('[db] getFixtures failed, falling back to in-memory: ' + e.message);
    return fixturesFallback[bucketKey] || null;
  }
}

// Updates ONLY the odds fields for one specific match — this is the atomic
// write that means a re-analysis (e.g. odds moving from 2.0 to 3.1 as new
// info comes in, or a live repricing) shows up immediately on the next
// read, from JuanAi's UI or BetaKE's API call, with no risk of clobbering
// unrelated fixture data written by a concurrent saveFixtures call.
async function upsertMatchOdds(matchId, days, odds) {
  // AI analysis only ever runs for football (basketball skips it by design
  // — see basketballData.js's file header) — so this always targets the
  // football-prefixed bucket key. Written explicitly here (not defaulted
  // via an optional param like saveFixtures/getFixtures) since there's
  // currently no legitimate basketball caller of this function at all.
  const bucketKey = 'football:' + String(days);
  await ensureMongo();
  const now = Date.now();

  if (usingFallback) {
    const bucket = fixturesFallback[bucketKey];
    if (!bucket) return false;
    let found = false;
    bucket.matches = bucket.matches.map(m => {
      if (String(m.id) === String(matchId)) {
        found = true;
        return Object.assign({}, m, { aiOdds: odds, aiPrediction: odds.prediction, aiConfidence: odds.confidence, aiAnalysis: odds.analysis, aiXG: { home: odds.xgHome, away: odds.xgAway }, aiValueBet: odds.valueBet, aiAnalyzedAt: now });
      }
      return m;
    });
    bucket.updatedAt = new Date().toISOString();
    return found;
  }

  try {
    const result = await fixturesCollection.updateOne(
      { matchId: String(matchId), days: bucketKey },
      {
        $set: {
          aiOdds: odds,
          aiPrediction: odds.prediction,
          aiConfidence: odds.confidence,
          aiAnalysis: odds.analysis,
          aiXG: { home: odds.xgHome, away: odds.xgAway },
          aiValueBet: odds.valueBet,
          aiAnalyzedAt: now,
          updatedAt: new Date().toISOString()
        }
      }
    );
    return result.matchedCount > 0;
  } catch (e) {
    console.error('[db] upsertMatchOdds failed: ' + e.message);
    return false;
  }
}
// ── API key storage (uses the SAME MongoDB connection as fixtures above) ──

function generateApiKey() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = 'jsk_';
  for (let i = 0; i < 32; i++) key += chars[Math.floor(Math.random() * chars.length)];
  return key;
}

async function getApiKeys() {
  await ensureMongo();
  if (usingFallback) return apiKeysFallback;
  try {
    return await apiKeysCollection.find({}).sort({ createdAt: -1 }).toArray();
  } catch (e) {
    console.error('[db] getApiKeys failed, falling back to in-memory: ' + e.message);
    return apiKeysFallback;
  }
}

async function addApiKey(name) {
  await ensureMongo();
  const record = {
    id: Date.now(),
    name: name || 'Unnamed key',
    key: generateApiKey(),
    createdAt: new Date().toISOString(),
    requests: 0,
    active: true
  };
  if (usingFallback) {
    apiKeysFallback.push(record);
    return record;
  }
  try {
    await apiKeysCollection.insertOne(record);
    return record;
  } catch (e) {
    console.error('[db] addApiKey failed, falling back to in-memory: ' + e.message);
    apiKeysFallback.push(record);
    return record;
  }
}

async function isValidApiKey(key) {
  if (!key) return false;
  await ensureMongo();
  if (usingFallback) {
    const found = apiKeysFallback.find(k => k.key === key && k.active);
    if (!found) return false;
    found.requests = (found.requests || 0) + 1;
    found.lastUsedAt = new Date().toISOString();
    return true;
  }
  try {
    const found = await apiKeysCollection.findOne({ key, active: true });
    if (!found) return false;
    await apiKeysCollection.updateOne(
      { key },
      { $inc: { requests: 1 }, $set: { lastUsedAt: new Date().toISOString() } }
    );
    return true;
  } catch (e) {
    console.error('[db] isValidApiKey failed: ' + e.message);
    return false;
  }
}

async function revokeApiKey(id) {
  await ensureMongo();
  if (usingFallback) {
    apiKeysFallback = apiKeysFallback.filter(k => k.id !== Number(id));
    return;
  }
  try {
    await apiKeysCollection.deleteOne({ id: Number(id) });
  } catch (e) {
    console.error('[db] revokeApiKey failed: ' + e.message);
  }
}

// ── Partner wallet config storage ──────────────────────────────────
// One document per partner API key: their wallet base URL + HMAC shared
// secret (see walletClient.js). Persisted the same way as API keys so a
// Render restart doesn't silently disable real-money debit/credit/balance
// calls — that would be a much worse surprise than losing fixture cache.
async function saveWallet(apiKey, baseUrl, secret) {
  await ensureMongo();
  const record = { apiKey, baseUrl, secret, updatedAt: new Date().toISOString() };
  if (usingFallback) {
    walletsFallback = walletsFallback.filter(w => w.apiKey !== apiKey);
    walletsFallback.push(record);
    return record;
  }
  try {
    await walletsCollection.updateOne({ apiKey }, { $set: record }, { upsert: true });
    return record;
  } catch (e) {
    console.error('[db] saveWallet failed, falling back to in-memory: ' + e.message);
    walletsFallback = walletsFallback.filter(w => w.apiKey !== apiKey);
    walletsFallback.push(record);
    return record;
  }
}

async function getWallet(apiKey) {
  await ensureMongo();
  if (usingFallback) {
    return walletsFallback.find(w => w.apiKey === apiKey) || null;
  }
  try {
    return await walletsCollection.findOne({ apiKey });
  } catch (e) {
    console.error('[db] getWallet failed: ' + e.message);
    return null;
  }
}

async function getAllWallets() {
  await ensureMongo();
  if (usingFallback) return walletsFallback;
  try {
    return await walletsCollection.find({}).toArray();
  } catch (e) {
    console.error('[db] getAllWallets failed: ' + e.message);
    return walletsFallback;
  }
}

function getMongoStatus() {
  if (!MONGO_URI) return { configured: false, connected: false, note: 'MONGO_URI not set — fixtures/odds AND API keys stored in-memory only, will NOT survive a restart' };
  return {
    configured: true,
    connected: mongoReady && !usingFallback,
    note: mongoReady && !usingFallback
      ? 'Connected — fixtures/odds AND API keys persist across restarts'
      : 'MONGO_URI set but connection failed — fixtures/odds AND API keys stored in-memory only, will NOT survive a restart'
  };
}

// Clears any previously-generated odds fields from a match — used to
// self-heal matches that got bad odds before the TBD/unknown-team filter
// existed. Safe no-op if the match never had odds in the first place.
async function clearMatchOdds(matchId, days) {
  // Only ever called from football's TBD self-heal path (see scheduler.js's
  // refreshFixturesForDay) — always football-prefixed, same reasoning as
  // upsertMatchOdds above.
  const bucketKey = 'football:' + String(days);
  await ensureMongo();
  if (usingFallback) {
    const bucket = fixturesFallback[bucketKey];
    if (!bucket) return;
    bucket.matches = bucket.matches.map(m => {
      if (String(m.id) === String(matchId)) {
        const { aiOdds, aiPrediction, aiConfidence, aiAnalysis, aiXG, aiValueBet, aiAnalyzedAt, ...rest } = m;
        return rest;
      }
      return m;
    });
    return;
  }
  try {
    await fixturesCollection.updateOne(
      { matchId: String(matchId), days: bucketKey },
      { $unset: { aiOdds: '', aiPrediction: '', aiConfidence: '', aiAnalysis: '', aiXG: '', aiValueBet: '', aiAnalyzedAt: '' } }
    );
  } catch (e) {
    console.error('[db] clearMatchOdds failed: ' + e.message);
  }
}

// Deletes any match whose kickoff was long enough ago that it is certainly
// over by now, REGARDLESS of what status any data source reports for it.
// This is the real fix for matches getting stuck showing as live/pending
// forever: odds-api.io doesn't have a true "in progress" status (only
// pending/settled/cancelled — confirmed via direct testing), and if a
// match ages out of odds-api.io's own /events feed before ever being
// marked "settled", nothing else would ever touch it again — it would just
// sit in the database with its last-known status permanently. A football
// match plus stoppage/extra time essentially never exceeds ~3 hours, so
// anything older than that is deleted outright — not just hidden — freeing
// the space and guaranteeing it can never show as live/pending again.
// Cleans up duplicate matches already sitting in the database from BEFORE
// the dedup fix in footballData.js existed — same two teams, kickoff times
// within 3 hours of each other, but different match IDs (one from
// football-data.org, one from odds-api.io, with slightly different
// competition-name strings that prevented the original merge-time dedup
// from catching them). When a duplicate pair is found, keeps whichever
// copy has real market odds (isRealMarketOdds) if only one does — since
// that's strictly better data — otherwise keeps the more recently updated
// one and deletes the other.
async function deduplicateExistingMatches() {
  await ensureMongo();
  if (usingFallback) return 0; // not worth implementing for the fallback path — this is a one-time cleanup, real Mongo is the real target

  try {
    const allDocs = await fixturesCollection.find({}).toArray();
    const toDelete = [];
    const seen = new Set();

    for (let i = 0; i < allDocs.length; i++) {
      if (seen.has(allDocs[i]._id?.toString())) continue;
      const a = allDocs[i].match;
      if (!a || !a.homeTeam || !a.awayTeam) continue;

      for (let j = i + 1; j < allDocs.length; j++) {
        if (seen.has(allDocs[j]._id?.toString())) continue;
        const b = allDocs[j].match;
        if (!b || !b.homeTeam || !b.awayTeam) continue;
        if (allDocs[i].days !== allDocs[j].days) continue; // only dedupe within the same day-bucket

        const sameTeams = realOdds.teamsMatch(a.homeTeam.name, b.homeTeam.name) &&
          realOdds.teamsMatch(a.awayTeam.name, b.awayTeam.name);
        if (!sameTeams) continue;
        if (!a.utcDate || !b.utcDate) continue;
        const hoursDiff = Math.abs(new Date(a.utcDate).getTime() - new Date(b.utcDate).getTime()) / (60 * 60 * 1000);
        if (hoursDiff > 3) continue;

        // Found a duplicate pair — decide which to keep.
        const aHasReal = a.aiOdds && a.aiOdds.isRealMarketOdds;
        const bHasReal = allDocs[j].aiOdds && allDocs[j].aiOdds.isRealMarketOdds;
        let deleteIdx;
        if (aHasReal && !bHasReal) deleteIdx = j;
        else if (bHasReal && !aHasReal) deleteIdx = i;
        else deleteIdx = (allDocs[i].updatedAt > allDocs[j].updatedAt) ? j : i;

        toDelete.push(allDocs[deleteIdx]._id);
        seen.add(allDocs[deleteIdx]._id?.toString());
        if (deleteIdx === i) break; // doc i itself was deleted, stop comparing it against further docs
      }
    }

    if (toDelete.length) {
      const result = await fixturesCollection.deleteMany({ _id: { $in: toDelete } });
      return result.deletedCount || 0;
    }
    return 0;
  } catch (e) {
    console.error('[db] deduplicateExistingMatches failed: ' + e.message);
    return 0;
  }
}

async function expireOldMatches() {
  await ensureMongo();
  const cutoff = new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(); // matches that kicked off more than 3 hours ago, regardless of reported status

  if (usingFallback) {
    let deletedCount = 0;
    Object.keys(fixturesFallback).forEach(days => {
      const bucket = fixturesFallback[days];
      if (!bucket) return;
      const before = bucket.matches.length;
      // Two deletion conditions: (1) explicitly FINISHED — delete
      // immediately, no need to wait for the time cutoff since we already
      // KNOW it's over; (2) time-based cutoff as a catch-all for matches
      // odds-api.io never marks "settled" at all.
      bucket.matches = bucket.matches.filter(m => m.status !== 'FINISHED' && (!m.utcDate || m.utcDate >= cutoff));
      deletedCount += before - bucket.matches.length;
    });
    return deletedCount;
  }

  try {
    // match.utcDate and match.status are both stored inside the nested
    // `match` object. Delete anything explicitly FINISHED immediately, OR
    // anything older than the time cutoff regardless of status (the
    // catch-all for matches odds-api.io never marks "settled"), OR anything
    // sitting in a day-bucket that's no longer refreshed at all (days 3-7,
    // orphaned when DAY_BUCKETS shrank to [0,1,2] to keep analysis volume
    // sustainable — this data would otherwise sit forever with no bucket
    // ever touching it again). Matched via regex against the sport-prefixed
    // bucket key format (e.g. "football:3", "basketball:5") introduced
    // alongside basketball support — the plain "3"/"4"/etc format no longer
    // exists as a key at all once every write goes through saveFixtures'
    // sport-prefixed bucketKey, so this must match the suffix, not the
    // whole string.
    const result = await fixturesCollection.deleteMany({
      $or: [
        { 'match.status': 'FINISHED' },
        { 'match.utcDate': { $lt: cutoff, $ne: null } },
        { days: { $regex: ':(3|4|5|6|7)$' } }
      ]
    });
    return result.deletedCount || 0;
  } catch (e) {
    console.error('[db] expireOldMatches failed: ' + e.message);
    return 0;
  }
}

module.exports = {
  saveFixtures,
  getFixtures,
  upsertMatchOdds,
  clearMatchOdds,
  expireOldMatches,
  deduplicateExistingMatches,
  getApiKeys,
  addApiKey,
  isValidApiKey,
  revokeApiKey,
  saveWallet,
  getWallet,
  getAllWallets,
  getMongoStatus,
  ensureMongo
};
